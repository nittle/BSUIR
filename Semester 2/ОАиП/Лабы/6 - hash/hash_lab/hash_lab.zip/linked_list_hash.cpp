/*
	To do:
	Hash table that stores variables within linked lists

	To do that I need:
	insert function
	find function
	hash function

	I will have an array of structs that contain info like:
	data
	next

	By default they will be nullptrs
*/

#include "linked_list_hash.h"

int hash(int key) {
	return key % 10;
}

void insert(PersonData data, PersonData** hashTable) {
	int hashIndex = hash(data.phoneNumber);

	PersonData* current = hashTable[hashIndex];

	if (current == nullptr) {
		hashTable[hashIndex] = new PersonData(data);
	}
	else {
		while (current->next != nullptr)
			current = current->next;
		current->next = new PersonData(data);
	}
}

PersonData* find(int key, PersonData** hashTable) {
	int hashIndex = hash(key);

	return hashTable[hashIndex];
}