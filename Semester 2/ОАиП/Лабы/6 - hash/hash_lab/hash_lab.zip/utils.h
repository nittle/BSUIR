#pragma once
#include<iostream>

template<typename T>
void print(T data, char end = '\n') {
	std::cout << data << end;
}

void print() {
	std::cout << '\n';
}

void input(int& destination) {
	std::cin >> destination;
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	std::cin.clear();
}

void input(char* destination) {
	std::cin.getline(destination, '\n');
	std::cin.clear();
}