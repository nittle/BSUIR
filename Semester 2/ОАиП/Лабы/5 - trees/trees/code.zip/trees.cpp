﻿#include "avl.h"
#include "utils.h"
#include <cstdlib>
#include <ctime>

// To implement:
// delete

int main()
{
    srand(time(NULL));

    Node *root = nullptr;
    root = insert(root, 12);

    // Inserts a number of unique and random elements
    const int numOfElements = 10;

    int usedElements[numOfElements];
    for (int i = 0; i < 10; i++)
    {
        bool isUnique;
        int random = rand() % 20 + 1;

        do
        {
            isUnique = true;
            random = rand() % 20 + 1;
            for (int j = 0; j < i; j++)
            {
                if (random == usedElements[j])
                    isUnique = false;
            }

        } while (!isUnique);

        usedElements[i] = random;
        root = insert(root, random);
    }
    
    
    preOrderTraversal(root);
    print();
    inOrderTraversal(root);
    print();
    postOrderTraversal(root);

    freeMemory(root);
}