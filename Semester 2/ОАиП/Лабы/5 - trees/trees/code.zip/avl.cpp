#include "utils.h"
#include "avl.h"


// Root left right
void preOrderTraversal(Node* node) {
    if (node == nullptr) {
        return;
    }

    print(node->info, ' ');
    preOrderTraversal(node->left);
    preOrderTraversal(node->right);
}

// Left root right
void inOrderTraversal(Node* node) {
    if (node == nullptr) {
        return;
    }

    inOrderTraversal(node->left);
    print(node->info, ' ');
    inOrderTraversal(node->right);
}

// Left right root
void postOrderTraversal(Node* node) {
    if (node == nullptr) {
        return;
    }

    postOrderTraversal(node->left);
    postOrderTraversal(node->right);
    print(node->info, ' ');
}

void freeMemory(Node* node) {
    if (node == nullptr) return;

    freeMemory(node->left);
    freeMemory(node->right);
    delete node;
}

int getHeight(Node* node) {
    if (node == nullptr) return 0;

    int leftHeight = getHeight(node->left);
    int rightHeight = getHeight(node->right);

    int max = leftHeight > rightHeight ? leftHeight : rightHeight;

    return 1 + max;
}

int getBalance(Node* node) {
    if (node == nullptr)
        return 0;

    return getHeight(node->left) - getHeight(node->right);
}

Node* rightRotate(Node* node) {
    print("Right rotate on", ' ');
    print(node->info);

    Node* x = node->left;
    Node* T2 = x->right;
    x->right = node;
    node->left = T2;
    
    return x;
}

Node* leftRotate(Node* node) {
    print("Left rotate on", ' ');
    print(node->info);

    Node* x = node->right;
    Node* T2 = x->left;
    x->right = node;
    node->left = T2;

    return x;
}

Node* insert(Node* node, int info) {
    if (node == nullptr) {
        Node* newNode = new Node();
        newNode->info = info;
        return newNode;
    }

    if (info < node->info) {
        node->left = insert(node->left, info);
    }
    else if (info > node->info) {
        node->right = insert(node->right, info);
    }
    else {
        return node;
    }

    // Balancing
    int balance = getBalance(node);

    // Left left
    if (balance > 1 && getBalance(node->left) >= 0) {
        return rightRotate(node);
    }
    // Left right
    if (balance > 1 && getBalance(node->left) < 0) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }
    // Right right
    if (balance < -1 && getBalance(node->right) <= 0) {
        return leftRotate(node);
    }
    // Right left
    if (balance < -1 && getBalance(node->right) > 0) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}